const CFG={
  sheets:["Plans","Users","Vendors","VendorUsers","Documents","Projects","Leads","Tasks","Payments","SupportTickets","AuditLog","Notifications","Settings"],
  sessionTTL:21600,
  rootFolder:"Solar EPC Platform"
};

function doGet(){return HtmlService.createTemplateFromFile("Index").evaluate().setTitle("Solar EPC Platform").setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL)}
function include(n){return HtmlService.createHtmlOutputFromFile(n).getContent()}

function setupSystem(){
 const ss=SpreadsheetApp.getActive();
 CFG.sheets.forEach(n=>{let s=ss.getSheetByName(n)||ss.insertSheet(n);if(s.getLastRow()===0)s.appendRow(headers_(n));});
 let f=DriveApp.getFoldersByName(CFG.rootFolder);let folder=f.hasNext()?f.next():DriveApp.createFolder(CFG.rootFolder);
 setSetting_("rootFolderId",folder.getId());
 seedPlans_();
 return {ok:true};
}
function createInitialAdmin(){
 setupSystem();
 if(rows_("Users").some(x=>x.role==="MASTER_ADMIN"))return {ok:false,message:"Master Admin already exists"};
 const password=temporaryPassword_();
 insert_("Users",{id:id_(),email:"admin@example.com",name:"Master Admin",phone:"",role:"MASTER_ADMIN",vendorId:"",planId:"",state:"",region:"",district:"",passwordHash:hash_(password),active:true,createdAt:now_(),lastLoginAt:""});
 return {email:"admin@example.com",temporaryPassword:password};
}
function login(email,password){
 const u=rows_("Users").find(x=>String(x.email).toLowerCase()===String(email).trim().toLowerCase());
 if(!u||!bool_(u.active)||!u.passwordHash||hash_(password)!==u.passwordHash)throw Error("Invalid credentials or inactive account");
 const token=Utilities.getUuid();CacheService.getScriptCache().put("s_"+token,JSON.stringify({userId:u.id,role:u.role,vendorId:u.vendorId||""}),CFG.sessionTTL);
 update_("Users",u.id,{lastLoginAt:now_()});return {token,user:safe_(u)};
}
function logout(token){CacheService.getScriptCache().remove("s_"+token);return true}
function me(token){const s=session_(token),u=one_("Users","id",s.userId);if(!u)throw Error("User not found");return {user:safe_(u),plan:u.planId?one_("Plans","id",u.planId):null}}
function dashboard(token){
 const s=session_(token),filter=a=>isAdmin_(s)?a:a.filter(x=>!x.vendorId||x.vendorId===s.vendorId);
 const projects=filter(rows_("Projects")),docs=filter(rows_("Documents")),leads=filter(rows_("Leads")),tasks=filter(rows_("Tasks")),tickets=filter(rows_("SupportTickets"));
 return {vendors:isAdmin_(s)?rows_("Vendors").length:1,users:filter(rows_("Users")).length,projects:projects.length,leads:leads.length,documents:docs.length,pendingDocuments:docs.filter(x=>x.status==="PENDING").length,openTasks:tasks.filter(x=>!["DONE","CLOSED"].includes(x.status)).length,openTickets:tickets.filter(x=>!["CLOSED","RESOLVED"].includes(x.status)).length};
}
function listData(token,name){
 const s=session_(token);if(!CFG.sheets.includes(name))throw Error("Invalid entity");
 let a=rows_(name);if(!isAdmin_(s))a=a.filter(x=>!x.vendorId||x.vendorId===s.vendorId);
 return name==="Users"?a.map(safe_):a;
}

function savePlan(token,p){
 require_(token,["MASTER_ADMIN","ADMIN"]);
 const x={id:p.id||id_(),name:p.name||"",code:p.code||"",monthlyPrice:num_(p.monthlyPrice),annualPrice:num_(p.annualPrice),maxUsers:num_(p.maxUsers,1),maxProjects:num_(p.maxProjects,10),maxStorageMB:num_(p.maxStorageMB,500),featuresJson:p.featuresJson||"{}",active:p.active!==false};
 insert_("Plans",x);audit_(token,"SAVE","Plans",x.id,x.name);return x;
}
function saveVendor(token,p){
 require_(token,["MASTER_ADMIN","ADMIN"]);
 const x={id:p.id||id_(),vendorCode:p.vendorCode||("EPC-"+shortId_()),companyName:p.companyName||"",legalName:p.legalName||"",gstin:p.gstin||"",pan:p.pan||"",cin:p.cin||"",email:p.email||"",phone:p.phone||"",address:p.address||"",state:p.state||"",district:p.district||"",pincode:p.pincode||"",website:p.website||"",status:p.status||"PENDING",planId:p.planId||"",ownerUserId:p.ownerUserId||"",createdAt:p.createdAt||now_(),updatedAt:now_()};
 insert_("Vendors",x);audit_(token,"SAVE","Vendors",x.id,x.companyName);return x;
}
function setVendorAccess(token,vendorId,active,planId){
 require_(token,["MASTER_ADMIN","ADMIN"]);const v=one_("Vendors","id",vendorId);if(!v)throw Error("Vendor not found");
 update_("Vendors",vendorId,{status:active?"ACTIVE":"SUSPENDED",planId:planId||v.planId,updatedAt:now_()});
 rows_("Users").filter(u=>u.vendorId===vendorId).forEach(u=>update_("Users",u.id,{active:!!active,planId:planId||u.planId}));
 audit_(token,active?"GRANT_VENDOR_ACCESS":"REMOVE_VENDOR_ACCESS","Vendors",vendorId,JSON.stringify({planId}));return true;
}
function createEpcUser(token,p){
 const s=require_(token,["MASTER_ADMIN","ADMIN"]),v=one_("Vendors","id",p.vendorId);if(!v)throw Error("Vendor not found");
 if(rows_("Users").some(u=>String(u.email).toLowerCase()===String(p.email).toLowerCase()))throw Error("Email already exists");
 const plan=v.planId?one_("Plans","id",v.planId):null,count=rows_("Users").filter(u=>u.vendorId===v.id&&bool_(u.active)).length;
 if(plan&&count>=Number(plan.maxUsers))throw Error("Plan user limit reached");
 const password=temporaryPassword_(),u={id:id_(),email:String(p.email).trim().toLowerCase(),name:p.name||"",phone:p.phone||"",role:"EPC_USER",vendorId:v.id,planId:v.planId||"",state:v.state||v.state||"",region:"",district:v.district||v.district||"",passwordHash:hash_(password),active:true,createdAt:now_(),lastLoginAt:""};
 insert_("Users",u);insert_("VendorUsers",{id:id_(),vendorId:v.id,userId:u.id,designation:p.designation||"EPC User",active:true});audit_(token,"CREATE","Users",u.id,u.email);return {user:safe_(u),temporaryPassword:password};
}
function setUserAccess(token,userId,active){require_(token,["MASTER_ADMIN","ADMIN"]);update_("Users",userId,{active:!!active});audit_(token,active?"GRANT_USER_ACCESS":"REMOVE_USER_ACCESS","Users",userId,String(active));return true}
function resetPassword(token,userId){require_(token,["MASTER_ADMIN","ADMIN"]);const p=temporaryPassword_();const u=one_("Users","id",userId);if(!u)throw Error("User not found");update_("Users",userId,{passwordHash:hash_(p)});audit_(token,"RESET_PASSWORD","Users",userId,u.email);return {email:u.email,temporaryPassword:p}}

function saveLead(token,p){const s=session_(token),vendorId=isAdmin_(s)?p.vendorId:s.vendorId;if(!vendorId)throw Error("Vendor required");const x={id:p.id||id_(),vendorId,customerName:p.customerName||"",phone:p.phone||"",email:p.email||"",location:p.location||"",capacityKW:num_(p.capacityKW),source:p.source||"",status:p.status||"WARM",ownerUserId:p.ownerUserId||s.userId,remarks:p.remarks||"",createdAt:p.createdAt||now_(),updatedAt:now_()};insert_("Leads",x);audit_(token,"SAVE","Leads",x.id,x.customerName);return x}
function saveProject(token,p){const s=session_(token),vendorId=isAdmin_(s)?p.vendorId:s.vendorId;if(!vendorId)throw Error("Vendor required");const existing=p.id?one_("Projects","id",p.id):null,plan=vendorPlan_(vendorId),count=rows_("Projects").filter(x=>x.vendorId===vendorId&&x.id!==p.id).length;if(!existing&&plan&&count>=Number(plan.maxProjects))throw Error("Plan project limit reached");const x={id:p.id||id_(),vendorId,projectCode:p.projectCode||("PRJ-"+shortId_()),customerName:p.customerName||"",capacityKW:num_(p.capacityKW),location:p.location||"",state:p.state||"",district:p.district||"",status:p.status||"PIPELINE",estimatedValue:num_(p.estimatedValue),startDate:p.startDate||"",targetDate:p.targetDate||"",createdAt:existing?existing.createdAt:now_(),updatedAt:now_()};insert_("Projects",x);audit_(token,"SAVE","Projects",x.id,x.customerName);return x}
function saveTask(token,p){const s=session_(token),vendorId=isAdmin_(s)?p.vendorId:s.vendorId,x={id:p.id||id_(),vendorId,assignedTo:p.assignedTo||s.userId,title:p.title||"",description:p.description||"",priority:p.priority||"MEDIUM",dueDate:p.dueDate||"",status:p.status||"OPEN",progress:num_(p.progress),remarks:p.remarks||"",createdBy:s.userId,createdAt:p.createdAt||now_(),updatedAt:now_()};insert_("Tasks",x);audit_(token,"SAVE","Tasks",x.id,x.title);return x}
function saveTicket(token,p){const s=session_(token),vendorId=isAdmin_(s)?p.vendorId:s.vendorId,x={id:p.id||id_(),vendorId,createdBy:s.userId,subject:p.subject||"",description:p.description||"",priority:p.priority||"MEDIUM",status:p.status||"OPEN",assignedTo:p.assignedTo||"",createdAt:p.createdAt||now_(),updatedAt:now_()};insert_("SupportTickets",x);audit_(token,"CREATE","SupportTickets",x.id,x.subject);return x}

function uploadDocument(token,meta,base64,mime){
 const s=session_(token),vendorId=isAdmin_(s)?meta.vendorId:s.vendorId;if(!vendorId)throw Error("Vendor required");
 if(!base64||base64.length>18*1024*1024)throw Error("File too large for this web upload");
 const folder=vendorFolder_(vendorId),blob=Utilities.newBlob(Utilities.base64Decode(base64),mime,meta.documentName),file=folder.createFile(blob);
 const x={id:id_(),vendorId,projectId:meta.projectId||"",documentType:meta.documentType||"OTHER",documentName:meta.documentName||file.getName(),fileId:file.getId(),fileUrl:file.getUrl(),status:"PENDING",uploadedBy:s.userId,uploadedAt:now_(),reviewedBy:"",reviewedAt:"",remarks:"",expiryDate:meta.expiryDate||""};
 insert_("Documents",x);audit_(token,"UPLOAD","Documents",x.id,x.documentName);return x;
}
function reviewDocument(token,id,status,remarks){const s=require_(token,["MASTER_ADMIN","ADMIN"]),d=one_("Documents","id",id);if(!d)throw Error("Document not found");if(!["APPROVED","REJECTED","PENDING"].includes(status))throw Error("Invalid document status");update_("Documents",id,{status,remarks:remarks||"",reviewedBy:s.userId,reviewedAt:now_()});audit_(token,"REVIEW","Documents",id,status);return true}

function notifications(token){
 const s=session_(token);return rows_("Notifications").filter(n=>n.userId===s.userId||n.vendorId===s.vendorId).slice(-100).reverse();
}

function headers_(n){const m={
Plans:["id","name","code","monthlyPrice","annualPrice","maxUsers","maxProjects","maxStorageMB","featuresJson","active"],
Users:["id","email","name","phone","role","vendorId","planId","state","region","district","passwordHash","active","createdAt","lastLoginAt"],
Vendors:["id","vendorCode","companyName","legalName","gstin","pan","cin","email","phone","address","state","district","pincode","website","status","planId","ownerUserId","createdAt","updatedAt"],
VendorUsers:["id","vendorId","userId","designation","active"],
Documents:["id","vendorId","projectId","documentType","documentName","fileId","fileUrl","status","uploadedBy","uploadedAt","reviewedBy","reviewedAt","remarks","expiryDate"],
Projects:["id","vendorId","projectCode","customerName","capacityKW","location","state","district","status","estimatedValue","startDate","targetDate","createdAt","updatedAt"],
Leads:["id","vendorId","customerName","phone","email","location","capacityKW","source","status","ownerUserId","remarks","createdAt","updatedAt"],
Tasks:["id","vendorId","assignedTo","title","description","priority","dueDate","status","progress","remarks","createdBy","createdAt","updatedAt"],
Payments:["id","vendorId","projectId","invoiceNo","amount","dueDate","paidDate","status","remarks"],
SupportTickets:["id","vendorId","createdBy","subject","description","priority","status","assignedTo","createdAt","updatedAt"],
AuditLog:["id","actorUserId","action","entity","entityId","details","timestamp"],
Notifications:["id","userId","vendorId","type","title","message","read","createdAt"],
Settings:["key","value"]};return m[n]||[]}

function rows_(name){const s=SpreadsheetApp.getActive().getSheetByName(name),v=s.getDataRange().getValues();if(v.length<2)return[];const h=v[0].map(String);return v.slice(1).filter(r=>r.some(x=>x!=="")).map(r=>Object.fromEntries(h.map((k,i)=>[k,r[i]])))}
function one_(name,key,val){return rows_(name).find(x=>String(x[key])===String(val))||null}
function insert_(name,obj){const s=SpreadsheetApp.getActive().getSheetByName(name),h=s.getRange(1,1,1,s.getLastColumn()).getValues()[0];const existing=obj.id?one_(name,"id",obj.id):null;const data=h.map(k=>obj[k]===undefined?"":obj[k]);if(!existing){s.appendRow(data);return obj}const vals=s.getDataRange().getValues(),idx=h.indexOf("id");for(let i=1;i<vals.length;i++)if(String(vals[i][idx])===String(obj.id)){s.getRange(i+1,1,1,h.length).setValues([data]);break}return obj}
function update_(name,id,p){const x=one_(name,"id",id);if(!x)throw Error("Record not found");Object.assign(x,p);insert_(name,x)}
function session_(t){if(!t)throw Error("Not authenticated");const x=CacheService.getScriptCache().get("s_"+t);if(!x)throw Error("Session expired");return JSON.parse(x)}
function require_(t,roles){const s=session_(t);if(!roles.includes(s.role))throw Error("Access denied");return s}
function isAdmin_(s){return ["MASTER_ADMIN","ADMIN"].includes(s.role)}
function safe_(x){const y={...x};delete y.passwordHash;return y}
function vendorPlan_(v){const x=one_("Vendors","id",v);return x&&x.planId?one_("Plans","id",x.planId):null}
function vendorFolder_(vendorId){const root=DriveApp.getFolderById(getSetting_("rootFolderId"));const v=one_("Vendors","id",vendorId);const n=(v?v.companyName:"Vendor")+" ["+vendorId.slice(0,8)+"]";const it=root.getFoldersByName(n);return it.hasNext()?it.next():root.createFolder(n)}
function audit_(t,a,e,i,d){const s=session_(t);SpreadsheetApp.getActive().getSheetByName("AuditLog").appendRow([id_(),s.userId,a,e,i,String(d||"").slice(0,5000),now_()])}
function setSetting_(k,v){const s=SpreadsheetApp.getActive().getSheetByName("Settings");const x=one_("Settings","key",k);if(x){const vals=s.getDataRange().getValues();for(let i=1;i<vals.length;i++)if(String(vals[i][0])===k){s.getRange(i+1,2).setValue(v);return}}s.appendRow([k,v])}
function getSetting_(k){const x=one_("Settings","key",k);return x?x.value:""}
function seedPlans_(){if(rows_("Plans").length)return;const s=SpreadsheetApp.getActive().getSheetByName("Plans");s.appendRow([id_(),"Basic","BASIC",0,0,2,10,500,JSON.stringify(["dashboard","profile","leads","projects","documents","support"]),true]);s.appendRow([id_(),"Professional","PRO",999,9999,10,100,5000,JSON.stringify(["*"]),true]);s.appendRow([id_(),"Enterprise","ENTERPRISE",4999,49999,100,1000,50000,JSON.stringify(["*"]),true])}
function hash_(s){return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,String(s),Utilities.Charset.UTF_8).map(b=>(b+256)%256).map(b=>b.toString(16).padStart(2,"0")).join("")}
function id_(){return Utilities.getUuid()}function shortId_(){return Utilities.getUuid().replace(/-/g,"").slice(0,8).toUpperCase()}function now_(){return new Date()}function temporaryPassword_(){return shortId_()+"aA9!"}function bool_(x){return x===true||String(x).toUpperCase()==="TRUE"}function num_(x,d=0){const n=Number(x);return Number.isFinite(n)?n:d}
