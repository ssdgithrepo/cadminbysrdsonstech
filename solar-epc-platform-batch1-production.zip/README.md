# Solar EPC CRM & Vendor Platform — Batch 1

Production-oriented foundation for a two-portal Solar EPC platform:
- Admin CRM portal
- EPC Vendor portal
- Google Sheets database
- Google Drive document storage
- Role-based access
- Plan-based limits
- Vendor onboarding
- Document workflow
- Audit logging

## Deployment
1. Create a Google Sheet and open Extensions → Apps Script.
2. Add all files from this package.
3. Run `setupSystem()` once.
4. Run `createInitialAdmin()` once.
5. Deploy as Web App.
6. Change the generated admin password immediately.
7. Open the Web App URL.

## Security
This batch uses server-side authorization and hashed passwords, but a public commercial deployment should additionally use Google OAuth/Workspace identity, HTTPS-only deployment, rate limiting, malware scanning and a formal privacy/security review.

## Batch 1 includes
- Authentication/session
- Master Admin/Admin/EPC roles
- Vendor onboarding
- Vendor approval/suspension
- Plan engine
- User access control
- EPC team users
- Document upload/review/expiry
- Leads
- Projects
- Tasks
- Support tickets
- Audit trail
- Dashboard
